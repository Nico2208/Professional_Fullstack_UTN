import React,{Component} from "react"
import Noticias from './Noticias'
class Home extends Component{
    render(){
        return(
            <div>
                <Noticias />
            </div>
        )
    }
}

export default Home